package pojo;

public class amessage {
    private String message;
    private  long time;

    public String getMessage() {
        return message;
    }

    public long getTime() {
        return time;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public void setTime(long time) {
        this.time = time;
    }
}
