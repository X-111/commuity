package pojo;

public class Deline {
    private  String receiver;
    private  long  lasttime;

    public void setReceiver(String receiver) {
        this.receiver = receiver;
    }

    public void setLasttime(int lasttime) {
        this.lasttime = lasttime;
    }

    public String getReceiver() {
        return receiver;
    }

    public long getLasttime() {
        return lasttime;
    }
}

