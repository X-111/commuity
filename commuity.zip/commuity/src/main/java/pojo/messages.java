package pojo;

import java.util.ArrayList;

public class messages {
    ArrayList<messages> allmessage;

    public ArrayList<messages> getAllmessage() {
        return allmessage;
    }

    public void setAllmessage(ArrayList<messages> allmessage) {
        this.allmessage = allmessage;
    }
}
